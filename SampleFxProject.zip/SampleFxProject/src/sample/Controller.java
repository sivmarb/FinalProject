package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import java.io.IOException;
import java.sql.*;
import java.util.HashMap;


public class Controller {

    private static final String USERNAME = "sivmarb";
    private static final String PASSWORD = "}am!j2eg";
    private static final String CONN_STRING = "jdbc:mysql://www.db4free.net:3306/ramenproject?verifyServerCertificate=false&useSSL=false";
    Connection conn = null;
    private ObservableList<String> ramenDropdown = FXCollections.observableArrayList("Shio (Salt) Ramen", "Shōyu (Soy Sauce) Ramen", "Tonkotsu (Pork Broth) Ramen");
    ObservableList<String> ramenItem = FXCollections.observableArrayList();
    @FXML
    public ComboBox<String> ramen_box;

    @FXML
    public ImageView imgGen;
    private String ramenPic;

    @FXML
    public TextArea ramen_text;

    @FXML
    private ListView<String> ramenListView;


    @FXML
    void add_btn(javafx.event.ActionEvent event) throws SQLException {

        String ramenName, ramenDesc;
       Statement stmt = null;

        conn = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
        System.out.println("Connection was made!");

        /**System.out.println("You are now connected!");
        String ramenName = ramen_box.getSelectionModel().getSelectedItem();
        String ramenDescription = ramen_text.getText();
        String sql = String.format("INSERT INTO ramenInfoTbl('ramen_name', 'ramenText') VALUES(%s %s);", ramenName, ramenDescription );

        conn.createStatement();
        stmt.executeUpdate(sql);
        System.out.println("Record Inserted");**/

        String sql = "INSERT INTO ramenInfoTbl (ramen_name, ramenText)" +
                "VALUES (?, ?)";
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
        preparedStatement.setString(1, ramen_box.getSelectionModel().getSelectedItem());
        preparedStatement.setString(2, ramen_text.getText());


        preparedStatement.executeUpdate();
        System.out.println("Record Inserted");



        //First add record to ListView
        String sql_getRamen_query = "SELECT ramen_name, ramenText FROM ramenInfoTbl WHERE ramen_name = ?";


        ResultSet rs = null;
        PreparedStatement ramenretrieve_stmt = conn.prepareStatement(sql_getRamen_query);

        ramenretrieve_stmt.setString(1, ramen_box.getSelectionModel().getSelectedItem());

        rs = ramenretrieve_stmt .executeQuery();

        while(rs.next()){

            ramenName = rs.getString(1);
            ramenDesc = rs.getString(2);

            ramenItem.add(new RamenInfo(ramenName, ramenDesc).getListView());
            System.out.println(ramenName + " " + ramenDesc);

        }
        ramenListView.setItems(ramenItem);



    }

    @FXML
    void del_btn(ActionEvent event) throws SQLException {

        //Connect to database
        conn = DriverManager.getConnection(CONN_STRING, USERNAME, PASSWORD);
        System.out.println("connection was made!");

        Statement deletestmt = null;

        conn.createStatement();

        String sqlDeleteStatement = "DELETE FROM ramenInfoTbl WHERE ramen_name = ?";
        PreparedStatement ramenRemoveStmt = conn.prepareStatement(sqlDeleteStatement);
        ramenRemoveStmt.setString(1, ramen_box.getSelectionModel().getSelectedItem());

        ramenRemoveStmt.executeUpdate();

        System.out.println("Record(s) removed!");

        ramenListView.getItems().remove(ramenItem);
        

    }

    @FXML
    void ramen_data(ActionEvent event) {

    }

    @FXML
    public void submit_btn(ActionEvent event) throws IOException {

        // text bot stuff
            String name, description;
            System.out.println(ramen_box.getSelectionModel().getSelectedItem());
            String selectedURL = ramenURL.get(ramen_box.getSelectionModel().getSelectedItem());
            Document doc = Jsoup.connect(selectedURL).get();
            Element aName = doc.select(".page-header__title").first();
            Element aDesc = doc.select(".WikiaArticle p").first();

            name = aName.text();
            description = aDesc.text();

            RamenInfo ramenName = new RamenInfo(name);
                    ramen_text.setText(ramenName.toString());
            RamenInfo ramenDesc = new RamenInfo(description);
                    ramen_text.setText(ramenDesc.toString());

            //ramen pictures in imageview
            imgGen.setImage(null);
            switch (ramen_box.getSelectionModel().getSelectedItem()){
                case "Shio (Salt) Ramen":
                    ramenPic = ("/images/shioramen.jpg");
                    break;
                case "Shōyu (Soy Sauce) Ramen":
                    ramenPic = ("/images/shoyuramen.jpg");
                    break;
                case "Tonkotsu (Pork Broth) Ramen":
                    ramenPic = ("/images/tonkotsuramen.jpg");
                    break;

            }
            try {
                Image ramenImages = new Image(ramenPic);
                imgGen.setImage(ramenImages);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    private HashMap<String, String> ramenURL;
    public void initialize() {

        //the stuff that goes into the TextArea (ramen_text)
        ramenURL = new HashMap<String, String>();
        ramenURL.put("Shio (Salt) Ramen", "https://ramen.fandom.com/wiki/Shio");
        ramenURL.put("Shōyu (Soy Sauce) Ramen", "https://ramen.fandom.com/wiki/Shōyu");
        ramenURL.put("Tonkotsu (Pork Broth) Ramen", "https://ramen.fandom.com/wiki/Tonkotsu");

        ramen_box.getItems().addAll(ramenURL.keySet());

        //ramen drop down
        ramen_box.setItems(ramenDropdown);

    }



}
