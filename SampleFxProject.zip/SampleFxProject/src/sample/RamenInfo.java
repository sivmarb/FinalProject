package sample;

public class RamenInfo {

    private String Name;
    private String Description;

    public RamenInfo(String name){
        Name = name;
        Description = name;

    }

    public RamenInfo(String name, String Description){
        this.Name = name;
        this.Description = Description;
    }


    public String getName(){

        return Name;
    }

    public String getListView(){
        return "Name: " + Name + " " + "Description: " + Description;
    }
    @Override
    public String toString(){

        return getName();

    }



}
